#!/usr/bin/env python3
"""Nioh 3 Mod Manager — Entry Point"""

from gui import main

if __name__ == "__main__":
    main()
