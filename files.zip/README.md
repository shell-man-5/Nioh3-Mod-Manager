# Nioh 3 Mod Manager

A GUI tool to manage mods for Nioh 3 (Steam version). Scans mod archives, detects
installable options, tracks installed mods, and handles the install/uninstall workflow
including the `yumia_mod_insert_into_rdb.exe` tool.

## How It Works

### Install flow
1. Scans your mods directory for `.zip` / `.7z` / `.rar` archives
2. Detects installable options by finding `package/` directories inside each archive
3. If multiple options exist (e.g. different colors/variants), lets you pick one
4. Extracts the chosen option's `package/` contents into `Nioh3/package/`
5. Runs `yumia_mod_insert_into_rdb.exe` to patch the RDB files

### Uninstall flow
1. Deletes the specific files that mod added to `Nioh3/package/`
2. Restores `system.rdb.original` → `system.rdb` and `root.rdb.original` → `root.rdb`
3. Re-runs yumia to re-apply all other installed mods

### Status tracking
- A manifest (`.nioh3_modmanager_manifest.json`) is stored in your mods directory
- On every startup/refresh, the manager **verifies** the manifest against reality
  by checking if each mod's files actually exist in the game directory
- If files are missing (e.g. you manually deleted them), the mod is marked as not installed

## Setup

### Prerequisites
- Python 3.10+
- The mod archives in a directory of your choosing
- Nioh 3 installed via Steam with `yumia_mod_insert_into_rdb.exe` in the `package/` dir

### Install dependencies
```bash
pip install -r requirements.txt
```

**Note:** `py7zr` and `rarfile` are optional — only needed if you have `.7z` or `.rar`
mod archives. For `.rar` support you also need `unrar` on your PATH.

### Run
```bash
python main.py
```

On first launch, click **⚙ Settings** to configure:
- **Mods Directory**: where your downloaded mod archives live
- **Game Package Directory**: typically `C:\Program Files (x86)\Steam\steamapps\common\Nioh3\package`

## Expected Mod Archive Structure

The manager looks for `package/` directories inside archives:

```
# Single-option mod:
my_cool_mod.zip
└── package/
    ├── some_file.bin
    └── another_file.dat

# Multi-option mod:
armor_colors.zip
├── Red/
│   └── package/
│       └── armor_texture.bin
├── Blue/
│   └── package/
│       └── armor_texture.bin
└── Gold/
    └── package/
        └── armor_texture.bin
```

For multi-option mods, the parent directory name (Red, Blue, Gold) becomes the
option label shown in the UI.

## Packaging as .exe (optional)

```bash
pip install pyinstaller
pyinstaller --onefile --windowed --name "Nioh3ModManager" main.py
```

The resulting `dist/Nioh3ModManager.exe` is a standalone executable.

## Steam Deck

This should work out of the box in Desktop Mode since PySide6 supports Linux.
You'll just need to adjust the game package directory path to wherever Steam
installed Nioh 3 under Proton (typically something like
`~/.steam/steam/steamapps/common/Nioh3/package`).

For running `yumia_mod_insert_into_rdb.exe` on Linux, you'll need to invoke it
through Proton — that's a TODO for a future version.
